<?php
$host='localhost';
$user='id13187155_mygoogle13';
$pass='Tyan_13051994';
$database='id13187155_mygoogle';

$conn = mysqli_connect($host,$user,$pass,$database);
?>